package dao;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;  
import java.sql.PreparedStatement; 

public class StrutsDao {
	// method for create connection
		public static Connection getConnection() throws Exception {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				return (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/m5?useSSL=false","root","");
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		// method for save user data in database
		public int registerUser(String uname, String uemail, String fname, String lname, String pass, String rpass, String phone, String address) throws Exception {
			int i = 0;
			try {
				String sql = "INSERT INTO data (uname, uemail, fname, lname, pass, rpass, phone, address) VALUES (?,?,?,?,?,?,?,?);";
				PreparedStatement ps = (PreparedStatement) getConnection().prepareStatement(sql);
				ps.setString(1, uname);
				ps.setString(2, uemail);
				ps.setString(3, fname);
				ps.setString(4, lname);
				ps.setString(5, pass);
				ps.setString(6, rpass);
				ps.setString(7, phone);
				ps.setString(8, address);
				i = ps.executeUpdate();
				return i;
			} catch (Exception e) {
				e.printStackTrace();
				return i;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}

		// method for fetch saved user data
		public ResultSet profile() throws SQLException, Exception {
			ResultSet rs = null;
			try {
				String sql = "SELECT uname, uemail, fname, lname, pass, rpass, phone, address FROM data";
				PreparedStatement ps = (PreparedStatement) getConnection().prepareStatement(sql);
				rs = ps.executeQuery();
				return rs;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}

		// method for fetch old data to be update
		public ResultSet fetchUserDetails(String uemail) throws SQLException, Exception {
			ResultSet rs = null;
			try {
				String sql = "SELECT uname, uemail, fname, lname, pass, rpass, phone, address FROM data WHERE uemail=?";
				PreparedStatement ps = (PreparedStatement) getConnection().prepareStatement(sql);
				ps.setString(1, uemail);
				rs = ps.executeQuery();
				return rs;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}

		// method for update new data in database
		public int updateUserDetails(String uname, String uemail, String fname, String lname, String pass, String rpass,
				String phone, String address, String uemailhidden) 
				throws SQLException, Exception {
			getConnection().setAutoCommit(false);
			int i = 0;
			try {
				String sql = "UPDATE data SET uname=?,uemail=?,fname=?,lname=?,pass=?,rpass=?,phone=?,address=? WHERE uemail=?";
				PreparedStatement ps = (PreparedStatement) getConnection().prepareStatement(sql);
				ps.setString(1, uname);
				ps.setString(2, uemail);
				ps.setString(3, fname);
				ps.setString(4, lname);
				ps.setString(5, pass);
				ps.setString(6, rpass);
				ps.setString(7, phone);
				ps.setString(8, address);
				ps.setString(9, uemailhidden);
				i = ps.executeUpdate();
				return i;
			} catch (Exception e) {
				e.printStackTrace();
				getConnection().rollback();
				return 0;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}

		// method for delete the record
		public int deleteUserDetails(String uemail) throws SQLException, Exception {
			getConnection().setAutoCommit(false);
			int i = 0;
			try {
				String sql = "DELETE FROM data WHERE uemail=?";
				PreparedStatement ps = (PreparedStatement) getConnection().prepareStatement(sql);
				ps.setString(1, uemail);
				i = ps.executeUpdate();
				return i;
			} catch (Exception e) {
				e.printStackTrace();
				getConnection().rollback();
				return 0;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}
		

		
		//login validation
		public static boolean validate(String uemail,String pass){  
			 boolean status=false;  
			  try{  
				   Class.forName("com.mysql.jdbc.Driver");  
				   Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/m5?useSSL=false","root","");  
				     
				   PreparedStatement ps=con.prepareStatement(  
				     "select * from data where uemail=? and pass=?"); 
			   ps.setString(1,uemail);  
			   ps.setString(2,pass); 
			   ResultSet rs=ps.executeQuery();  
			   status=rs.next();  
			  }catch(Exception e){e.printStackTrace();}  
			 return status;  
			}

}