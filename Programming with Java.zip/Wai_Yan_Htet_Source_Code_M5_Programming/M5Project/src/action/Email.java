package action;

import com.opensymphony.xwork2.ActionSupport;

public class Email extends ActionSupport{

	private static final long serialVersionUID = 1L;
	
	public String execute() throws Exception {
		return "EMAIL";
		}
	}