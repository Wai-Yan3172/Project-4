package action;

import java.sql.ResultSet;

import com.opensymphony.xwork2.ActionSupport;

import dao.StrutsDao;


public class UpdateAction extends ActionSupport{


	private static final long serialVersionUID = 1L;
	private String uname = "", uemail = "", fname = "", lname = "", pass = "", rpass = "",phone = "", address = "", uemailhidden = "";
	private String msg = "";
	ResultSet rs = null;
	StrutsDao dao = new StrutsDao();
	String submitType;

	@Override
	public String execute() throws Exception {
		try {
				int i = dao.updateUserDetails(uname, uemail, fname, lname, pass, rpass, phone, address, uemailhidden);
				if (i > 0) {
					msg = "Record Updated Successfuly";
				} else {
					msg = "error";
				}
			}catch (Exception e) {
			e.printStackTrace();
		}

		return "UPDATE";
	}

	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUemail() {
		return uemail;
	}
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getRpass() {
		return rpass;
	}
	public void setRpass(String rpass) {
		this.rpass = rpass;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String setSubmitType() {
		return submitType;
	}

	public void setSubmitType(String submitType) {
		this.submitType = submitType;
	}

	public String getUemailhidden() {
		return uemailhidden;
	}

	public void setUemailhidden(String uemailhidden) {
		this.uemailhidden = uemailhidden;
	}

}
