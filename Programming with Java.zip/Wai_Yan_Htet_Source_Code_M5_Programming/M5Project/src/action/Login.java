package action;  

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
 
import com.opensymphony.xwork2.ActionSupport;

public class Login extends ActionSupport{
	private static final long serialVersionUID = 1L;
	private String uemail;
	   private String pass; 
	   private String uname, fname, lname, rpass, phone, address;

	   public String execute() {
	      String ret = ERROR;
	      Connection conn = null;

	      try {
	         String URL = "jdbc:mysql://localhost/m5";
	         Class.forName("com.mysql.jdbc.Driver");
	         conn = DriverManager.getConnection(URL, "root", "");
	         String sql = "SELECT uname, uemail, fname, lname, pass, rpass, phone, address FROM data WHERE";
	         sql+=" uemail = ? AND pass = ?";
	         PreparedStatement ps = conn.prepareStatement(sql);
	         ps.setString(1, uemail);
	         ps.setString(2, pass);
	         ResultSet rs = ps.executeQuery();

	         while (rs.next()) {
	        	 uname = rs.getString(1);
	        	 uemail = rs.getString(2);
	        	 fname= rs.getString(3);
	        	 lname = rs.getString(4);
	        	 pass = rs.getString(5);
	        	 rpass = rs.getString(6);
	        	 phone = rs.getString(7);
	        	 address = rs.getString(8);
	            
	            ret = "success";
	         }
	      } catch (Exception e) {
	         ret = "error";
	      } finally {
	         if (conn != null) {
	            try {
	               conn.close();
	            } catch (Exception e) {
	            }
	         }
	      }
	      return ret;
	   }
	   public String getUname() {
			return uname;
		}
		public void setUname(String uname) {
			this.uname = uname;
		}
		public String getUemail() {
			return uemail;
		}
		public void setUemail(String uemail) {
			this.uemail = uemail;
		}
		public String getFname() {
			return fname;
		}
		public void setFname(String fname) {
			this.fname = fname;
		}
		public String getLname() {
			return lname;
		}
		public void setLname(String lname) {
			this.lname = lname;
		}
		public String getPass() {
			return pass;
		}
		public void setPass(String pass) {
			this.pass = pass;
		}
		public String getRpass() {
			return rpass;
		}
		public void setRpass(String rpass) {
			this.rpass = rpass;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}	  
		public String logout(){   
		    return "success";  
		}  
}
